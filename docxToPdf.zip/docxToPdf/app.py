from flask import Flask, request
from flask_restful import Api
import base64
import logging

logging.getLogger().setLevel(logging.INFO)

app = Flask(__name__)

api = Api(app)
import io

import subprocess
import os 
import time

BASE_DIR = os.path.dirname(__file__)
INPUT_DIR= os.path.join(BASE_DIR,"input_document")
OUTPUT_DIR=os.path.join(BASE_DIR,"output_document")


def generate_pdf( doc_path,pdf_path):
    logging.info("generating pdf phase")

    subprocess.call(
        [
            "soffice",
            # '--headless',
            "--convert-to",
            "pdf",
            "--outdir",
            pdf_path,
            doc_path,
        ]
    )
    logging.info("pdf generation successfull")
    return doc_path



def validate_request_data(json):
    if isinstance(json.get("data"), str) and isinstance(json.get("inputFileName"),str):
        return True
    return False


@app.route("/doc-to-pdf", methods=["POST"])
def process_document_conversion():
    response_json = {"success": False}
    try:
        content_type = request.headers.get("Content-Type")
        if content_type == "application/json":
            json = request.json
            logging.info(BASE_DIR,"BASE_DIR")
            logging.info(INPUT_DIR,"INPUT DIR")
            logging.info(OUTPUT_DIR,"OUTPUT DIR")

            if validate_request_data(json):
                file_data = json.get("data")
                input_file_name = json.get("inputFileName")
                # decode data 

                file_data = base64.b64decode(file_data)

                # save file in input dir 

                with open(os.path.join(INPUT_DIR,input_file_name),"wb") as f:
                    logging.info("writing file dat in as %s",input_file_name)
                    f.write(file_data)
                    logging.info("write success")

                doc_path = os.path.join(INPUT_DIR,input_file_name)
                pdf_path = os.path.join(OUTPUT_DIR)
                logging.info("__docpath",doc_path)
                logging.info("__pdfpath",pdf_path)

                generate_pdf(doc_path,pdf_path)
                output_name= str(input_file_name).split(".")[0]+".pdf"

                
                RetryCount=0
                is_file=False
                while RetryCount < 5:
                    is_file = os.path.isfile(os.path.join(pdf_path,output_name))

                    if is_file:
                        break
                    RetryCount+=1
                    time.sleep(0.05)
                    
                if is_file:
                    logging.info("file %s exists",os.path.join(pdf_path,output_name))
                    with io.open(os.path.join(pdf_path,output_name),"rb") as fp:
                        bytes = fp.read()

                    b64_bytes= base64.b64encode(bytes)
                    b64_string= b64_bytes.decode('utf-8')

                    response_json["data"]=b64_string

                else:
                    response_json["message"] = "Retries exceeded, could not generate pdf"
                    return response_json
                response_json["success"]=True
            else:

                logging.info("not json")
                response_json["message"] = "Invalid Body Values!"
                return response_json
        else:
            response_json["message"] = "Unsupported Content Type"
        

    except Exception as e:
        logging.info("the exception in conversion is %s ",e)
    return response_json


if __name__ == "__main__":
    app.run(debug=True)
